package Customer_Management_System.CRM.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Customer_Management_System.CRM.dao.CustomerDao;
import Customer_Management_System.CRM.entity.Customer;

@Service
public class CustomerService {

	@Autowired
	CustomerDao dao;
	
	public List<Customer> getall() {
		List<Customer> list=dao.getall();
		return list;
	}

	public String insertcustomer(Customer cust) {
		String msg=dao.insertcustomer(cust);
		return msg;
	}


	public String updatecust(Customer cust) {
		String msg=dao.updatecust(cust);
		return msg;
	}


	public String deletecustomerById(int id) {
		String msg=dao.deletecustomerById(id);
		return msg;
	}


}
