package Customer_Management_System.CRM.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import Customer_Management_System.CRM.entity.Customer;
import Customer_Management_System.CRM.service.CustomerService;

@RestController
public class CustomerController {
	
	@Autowired
	CustomerService service;
	
	@GetMapping("/allcut")
	public List<Customer> getall() {
		List<Customer> list=service.getall();
		return list;
	}
	@PostMapping("/insertcust")
	public String insertcustomer(@RequestBody Customer cust) {
		String msg=service.insertcustomer(cust);
		return msg;
	}
	
	@PutMapping("/updatecust")
	public String updatecust(@RequestBody Customer cust) {
		String msg=service.updatecust(cust);
		return msg;
	}
	
	@DeleteMapping("/deletecust/{id}")
	public String deletecustomerById(@PathVariable int id) {
		String msg=service.deletecustomerById(id);
		return msg;
	}

}
