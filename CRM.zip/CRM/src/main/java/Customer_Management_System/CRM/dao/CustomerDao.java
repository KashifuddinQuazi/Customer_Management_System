package Customer_Management_System.CRM.dao;


import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.criteria.spi.CriteriaBuilderExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import Customer_Management_System.CRM.entity.Customer;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.websocket.Session;

@Repository
public class CustomerDao {
	
	@Autowired
	SessionFactory sf;
	
	@PersistenceContext
    private EntityManager entityManager;

	


	public List<Customer> getall() {
        TypedQuery<Customer> query = entityManager.createQuery("FROM Customer", Customer.class);
        return query.getResultList();
    }

	
	public String insertcustomer(Customer cust) {
		org.hibernate.Session session=sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(cust);
		transaction.commit();
		session.close();
		return "customer inerted succefully";
	}

	public String updatecust(Customer cust) {
		org.hibernate.Session session=sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.update(cust);
		transaction.commit();
		session.close();
		return "customer details updated...";
		
	}

	public String deletecustomerById(int id) {
		org.hibernate.Session session=sf.openSession();
		Transaction transaction = session.beginTransaction();
		Customer customer= session.load(Customer.class, id);
		session.delete(customer);
		transaction.commit();
		session.close();
		return "Customer deleted succeessfully...";
		
	}
	


		
	}


	
	


